<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gerai extends Model
{
    protected $table = 'gerai';
	protected $primaryKey = 'id_gerai';
}
