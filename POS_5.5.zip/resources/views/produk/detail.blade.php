<!-- <div class="modal" id="modal-detail" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
 
   <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"> &times; </span> </button>
      <h3 class="modal-title">Detail Produk</h3>
   </div>
            
<div class="modal-body">
   
   <table class="table table-striped tabel-detail">
      <thead>
         <tr>
         <th width="20">No</th>
         <th>Kode Produk</th>
         <th>Nama Produk</th>
         <th>Kategori</th>
         <th>Deskripsi</th>
         <th>Harga Beli</th>
         <th>Harga Jual</th>
         <th>Diskon</th>
         <th>Stok</th>
         </tr>
      </thead>
      <tbody></tbody>   
   </table>
   
</div>
         
   </form>

         </div>
      </div>
   </div> -->
