

<?php $__env->startSection('title'); ?>
  Baranda
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
   ##parent-placeholder-6e5ce570b4af9c70279294e1a958333ab1037c86##  
   <li>Dashboard</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
<div class="row">
  <div class="col-xs-12">
    <div class="box">
       <div class="box-body text-center">
            <h2>Anda login sebagai KASIR</h2>
            <br><br>
            <a class="btn btn-success btn-lg" href="<?php echo e(route('transaksi.new')); ?>">Transaksi Baru</a>
            <br><br><br>
      </div>
   </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>