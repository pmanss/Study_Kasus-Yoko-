<!DOCTYPE html>
<html>
<head>
   <title>Cetak Kartu Member</title>

   <style>
     .box{position: relative;}
     .card{ width: 501.732pt; height: 147.402pt; }
     .kode{ 
        position: absolute; 
        top: 110pt; 
        left: 10pt; 
        color: #fff;
        font-size: 15pt;
      }
      .barcode{ 
        position: absolute; 
        top: 15pt; 
        left: 280pt; 
        font-size: 10pt;
      }
   </style>
</head>
<body>
   <table width="100%">      
    
    <?php $__currentLoopData = $datamember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td align="center">
      <div class="box">
        <img src="<?php echo e(('images/card.png')); ?>" class="card">
        <div class="kode"><b><?php echo e($data->nama); ?></b></div>
        <div class="barcode">
          <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG( $data->kode_member, 'C39')); ?>" height="30" width="130">
          <br><?php echo e($data->kode_member); ?>

        </div>
      </div>
      </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   </table>
</body>
</html>