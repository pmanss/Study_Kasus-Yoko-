

<?php $__env->startSection('title'); ?>
  Selesai Transaksi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
   ##parent-placeholder-6e5ce570b4af9c70279294e1a958333ab1037c86##  
   <li>Transaksi</li>
   <li>Selesai</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
<div class="row">
  <div class="col-xs-12">
    <div class="box">
       <div class="box-body">
          <div class="alert alert-success alert-dismissible">
            <i class="icon fa fa-check"></i>
            Data Transaksi telah disimpan.
          </div>

          <br><br>
          <?php if($setting->tipe_nota==0): ?>
            <a class="btn btn-warning btn-lg" href="<?php echo e(route('transaksi.cetak')); ?>">Cetak Ulang Nota</a>
          <?php else: ?>
            <a class="btn btn-warning btn-lg" onclick="tampilNota()">Cetak Ulang Nota</a>
            <script type="text/javascript">
              tampilNota();
              function tampilNota(){
                window.open("<?php echo e(route('transaksi.pdf')); ?>", "Nota PDF", "height=650,width=1024,left=150,scrollbars=yes");
              }              
            </script>
          <?php endif; ?>
          <a class="btn btn-primary btn-lg" href="<?php echo e(route('transaksi.new')); ?>">Transaksi Baru</a>
          <br><br><br><br>
      </div>
   </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>