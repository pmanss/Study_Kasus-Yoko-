

<?php $__env->startSection('title'); ?>
  Laporan Pendapatan <?php echo e(tanggal_indonesia($awal, false)); ?> s/d <?php echo e(tanggal_indonesia($akhir, false)); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
   ##parent-placeholder-6e5ce570b4af9c70279294e1a958333ab1037c86##
   <li>laporan</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>     
<div class="row">
  <div class="col-xs-12">
    <div class="box">
      <div class="box-header">
        <a onclick="periodeForm()" class="btn btn-success"><i class="fa fa-plus-circle"></i> Ubah Periode</a>
        <a href="laporan/pdf/<?php echo e($awal); ?>/<?php echo e($akhir); ?>" target="_blank" class="btn btn-info"><i class="fa fa-file-pdf-o"></i> Export PDF</a>
      </div>
      <div class="box-body">  

<table class="table table-striped tabel-laporan">
<thead>
   <tr>
      <th width="30">No</th>
      <th>Tanggal</th>
      <th>Penjualan</th>
      <th>Pembelian</th>
      <!-- <th>Pengeluaran</th> -->
      <th>Pendapatan</th>
   </tr>
</thead>
<tbody></tbody>
</table>

      </div>
    </div>
  </div>
</div>

<?php echo $__env->make('laporan.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
var table, awal, akhir;
$(function(){
   $('#awal, #akhir').datepicker({
     format: 'yyyy-mm-dd',
     autoclose: true
   });

   table = $('.tabel-laporan').DataTable({
     "dom" : 'Brt',
     "bSort" : false,
     "bPaginate" : false,
     "processing" : true,
     "serverside" : true,
     "ajax" : {
       "url" : "laporan/data/<?php echo e($awal); ?>/<?php echo e($akhir); ?>",
       "type" : "GET"
     }
   }); 

});

function periodeForm(){
   $('#modal-form').modal('show');        
}

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>