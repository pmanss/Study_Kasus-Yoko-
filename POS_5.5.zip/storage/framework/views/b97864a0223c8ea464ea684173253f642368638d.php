<?php $__env->startSection('title'); ?>
  Kartu Stok
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
   ##parent-placeholder-6e5ce570b4af9c70279294e1a958333ab1037c86##
   <li>Kartu stok</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>     
<div class="row">
  <div class="col-xs-12">
    <div class="box">
      <div class="box-header">
        <!-- <a onclick="addForm()" class="btn btn-success"><i class="fa fa-plus-circle"></i> Tambah</a>
        <a onclick="deleteAll()" class="btn btn-danger"><i class="fa fa-trash"></i> Hapus</a>
        <a onclick="printBarcode()" class="btn btn-info"><i class="fa fa-barcode"></i> Cetak Barcode</a> -->
      </div>
      <div class="box-body">  

<form method="post">
<?php echo e(csrf_field()); ?>

<table class="table table-striped">
<thead>
   <tr>
      <th width="20"><input type="checkbox" value="1" id="select-all"></th>

      <th>Produk</th>
      <th>Kategori</th>
      <th>Stok Awal</th>
      <th>Stok Masuk</th>
      <th>Stok Keluar</th>
      <th>Penjualan</th>
      <th>Transfer</th>
      <th>Penyesuaian</th>
      <th>Stok Akhir</th>
   </tr>
</thead>
<tbody></tbody>
</table>
</form>

      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>