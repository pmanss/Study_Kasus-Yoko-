<!DOCTYPE html>
<html>
<head>
   <title>Cetak Barcode</title>
</head>
<body>
   <table width="100%">   
     <tr>
      
      <?php $__currentLoopData = $dataproduk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <td align="center" style="border: 1px solid #ccc">
      <?php echo e($data->nama_produk); ?> - Rp. <?php echo e(format_uang($data->harga_jual)); ?></span><br>
      <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG( $data->kode_produk, 'C39')); ?>" height="60" width="180">
      <br><?php echo e($data->kode_produk); ?>

      </td>
      <?php if( $no++ % 3 == 0): ?>
         </tr><tr>
      <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
     </tr>
   </table>
</body>
</html>