<div class="modal" id="modal-produk" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
	  
   <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"> &times; </span> </button>
      <h3 class="modal-title">Cari Produk</h3>
   </div>
				
<div class="modal-body">
	<table class="table table-striped tabel-produk">
		<thead>
		   <tr>
		      <th>Kode Produk</th>
		      <th>Nama Produk</th>
		      <th>Harga Beli</th>
		      <th>Aksi</th>
		   </tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
		      <th><?php echo e($data->kode_produk); ?></th>
		      <th><?php echo e($data->nama_produk); ?></th>
		      <th>Rp. <?php echo e(format_uang($data->harga_beli)); ?></th>
		      <th><a onclick="selectItem(<?php echo e($data->kode_produk); ?>)" class="btn btn-primary"><i class="fa fa-check-circle"></i> Pilih</a></th>
		    </tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>

</div>
		
         </div>
      </div>
   </div>
